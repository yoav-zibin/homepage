import java.io.*;
import java.util.*;
import java.lang.reflect.*;

public class Hierarchy {
	static Object object = new Object();
	static public Class[] getSuperClasses(Class c) {
		Class superclass = c.getSuperclass();
		Class[] interfaces = c.getInterfaces();
		int supersNum=interfaces.length;
		if (superclass!=null) ++supersNum;
		if (c.isInterface()) ++supersNum;

		Class[] supers = new Class[supersNum];
		int added = 0;
		for(int i=0; i<interfaces.length; i++)
			supers[added++] = interfaces[i];
		if (superclass!=null)
			supers[added++] = superclass;
		if (c.isInterface())
			supers[added++] = object.getClass();
		return supers;
	}
	
	private Class forName(String s) {
		try {
			return Class.forName(s);
		} catch(Throwable e) {
			err.println("Loading '" + s + "' went bad:" + e.getMessage() );
			e.printStackTrace(err);
			err.flush();
		}
		return null;
	}
	

	Hashtable hash = new Hashtable();
	Vector names = new Vector();
	PrintWriter err = null;
	PrintWriter out = null;
	
	public void run(String listFileName, int from, int to) throws Throwable {

		BufferedReader in=null;
		err = new PrintWriter( new FileOutputStream(listFileName + ".err.txt") );
		//err = new PrintWriter( System.err );
		out = new PrintWriter( new FileOutputStream(listFileName + ".inh5") );
		in = new BufferedReader(new FileReader(listFileName + ".list"));
		 
		String name="";
		while( (name=in.readLine()) != null) {
			if (name.equals("")) continue;
			
			names.add(name);
			hash.put(name, Boolean.TRUE);
		}
		in.close();

		for(int i=from; i<to; i++) {
			if (i >= names.size()) {
				System.err.println("Finished checking all classes in: " + listFileName);
				break;
			}
			name = (String) names.get(i);

			System.out.println("Loading: " + name); System.out.flush();
			Class c = forName(name);
			if (c!=null)
				printInfo(c);
		}
		err.flush();
		out.flush();
		err.close();
		out.close();

		out = new PrintWriter( new FileOutputStream(listFileName + ".list") );
		for(int i=0; i<names.size(); i++)
			out.println(names.get(i));
		out.flush();
		out.close();

		System.err.println("from=" + from + " to=" + to + " ,size=" + names.size() + ". Finished in: " + listFileName); System.err.flush();
	}

	public void printInfo(Class c) {
		//out.println("Info for: " + c);
		//Modifier::toString( c.getModifiers() ); 
		
		if (c.isInterface())
			out.print("interface: ");
		else
			out.print("class: ");
		
		out.println( c.getName() );
		
		
		Class[] supers = getSuperClasses(c);
		out.println(supers.length + " supers: ");
		for(int i=0; i<supers.length; i++) {
			String superName = supers[i].getName();
			out.println("\t" + superName);
			if (!hash.containsKey(superName)) {
				//err.println("The file list should be full! missing class '" + superName + "'!");
				names.add(superName);
				hash.put(superName, Boolean.TRUE);
			}
		}
		

		Vector method_names = new Vector();

		try {
			Method[] methods = c.getDeclaredMethods(); //c.getMethods();
			for(int i=0; i<methods.length; i++) {
				Method m = methods[i];
				int modifiers = m.getModifiers();
				if ( (Modifier.isPublic(modifiers) || Modifier.isProtected(modifiers))
					 && !Modifier.isStatic(modifiers) ) {
					// not constructors or finalize

					String name = m.getReturnType().getName() + "-" + m.getName();
					Class[] param = m.getParameterTypes();
					for(int j=0; j<param.length; j++)
						name = name + "-" + param[j].getName();

					method_names.add(name);
				}
			}
		} catch(Throwable e) {
			err.println("getDeclaredMethods for class '" + c.getName() + "' went bad:" + e.getMessage() );
			e.printStackTrace(err);
			err.flush();
		}
		
		
		out.println(method_names.size() + " methods: ");	
		for(int i=0; i<method_names.size(); i++) {
			out.println( "\t" + method_names.get(i));
		}
	}


	static public void main(String[] args) {
		if (args.length!=3) {
			System.out.println("Usage: Hierarchy <listFile> <from> <to>\n");
			System.exit(1);
		}
		try {
			int from = Integer.parseInt(args[1]);
			int to = Integer.parseInt(args[2]);
			Hierarchy prog = new Hierarchy();
			prog.run(args[0], from, to);
		} catch(Throwable e) {
			System.err.println(e);
			e.printStackTrace(System.err);
			System.exit(1);
		}
	}

}