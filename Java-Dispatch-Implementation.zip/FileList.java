import java.io.*;
import java.util.*;

public class FileList {

	static private String[] getClassFiles(String path) {
		FilenameFilter classFilter = new FilenameFilter() {
			public boolean accept(File dir, String name) {
				return name.endsWith(".class");
			}
		};
		File f = new File(path);
		String[] res = f.list(classFilter);
		for(int i=0; i<res.length; i++)
			res[i] = res[i].substring(0, res[i].length()-6); // removing '.class'
		return res;
	}
	
	static private String[] getAllClassFiles(String path) {
		Vector v = new Vector();

		String[] names = getClassFiles(path);
		for(int i=0; i<names.length; i++)
			v.add(names[i]);

		File f = new File(path);
		FileFilter dirFilter = new FileFilter() {
			public boolean accept(File pathname) {
				return pathname.isDirectory();
			}
		};
		File[] dirs = f.listFiles(dirFilter);
		for(int i=0; i<dirs.length; i++) {
			String dirName = dirs[i].getName();
			names = getAllClassFiles(path + "\\" + dirName);
			for(int j=0; j<names.length; j++)
				v.add(dirName + "." + names[j]);
		}

		names = new String[v.size()];
		v.copyInto(names);
		return names;
	}

	static public void main(String[] args) {
		if (args.length!=1) {
			System.err.println("Usage: java FileList path");
			System.exit(1);
		}
		String[] files = getAllClassFiles(args[0]);
		for(int i=0; i<files.length; i++)
			System.out.println( files[i] );
		System.out.print("\n");
	}
}